// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TELLO_MSGS__MSG__TELLO_RESPONSE_HPP_
#define TELLO_MSGS__MSG__TELLO_RESPONSE_HPP_

#include "tello_msgs/msg/tello_response__struct.hpp"
#include "tello_msgs/msg/tello_response__traits.hpp"

#endif  // TELLO_MSGS__MSG__TELLO_RESPONSE_HPP_
