// generated from rosidl_generator_c/resource/idl.h.em
// with input from tello_msgs:msg/FlightData.idl
// generated code does not contain a copyright notice

#ifndef TELLO_MSGS__MSG__FLIGHT_DATA_H_
#define TELLO_MSGS__MSG__FLIGHT_DATA_H_

#include "tello_msgs/msg/flight_data__struct.h"
#include "tello_msgs/msg/flight_data__functions.h"
#include "tello_msgs/msg/flight_data__type_support.h"

#endif  // TELLO_MSGS__MSG__FLIGHT_DATA_H_
