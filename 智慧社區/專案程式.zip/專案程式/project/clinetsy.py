from flask import Flask,render_template,request,redirect,session,url_for
import purchase as purchase
import sqlite3
import time
import os

app=Flask(__name__, static_folder='templates')
app.secret_key = os.urandom(24)
# 登入系統oo
@app.route('/',methods=['POST','GET'])
def index():
	conn = sqlite3.connect('personal.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	rows = cursor.fetchall()

	conn1 = sqlite3.connect('news.sqlite')
	cursor1=conn1.execute("select * from NEWS")
	rownews = cursor1.fetchall()
	
	n = 0
	count = 0
	for rownew in rownews:
		count = count +1
	
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			
			new2 = rownew[1]
	if request.method =='POST':
		
		if request.values.get('var')=='首頁':
			return render_template('index.html',acc="")
		if request.values.get('var')=='登入1':
			return render_template('login.html',acc="")
		if request.values.get('var')=='person':
			acc = request.values['acc']
			
			
			for row in rows:
				if(acc == row[1]):
					purchase.set_User_accouent(row[0])
					return render_template('person.html', name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2)
		
		
		if request.values['var']=='登入':
			acc = request.values['account']
			pas = request.values['password']
			f = 1
			for row in rows:
				if(acc == row[2] and pas == row[3] and row[9]=="custom" and row[8]=="0"):
					f = 0
					session['user'] = request.form['account']
					print("1")
					sqlstr = "UPDATE PERSONAL SET online={} WHERE account='{}'".format(1,row[2])


					conn.execute(sqlstr)
					conn.commit()
					purchase.set_User_accouent(row[0])
					return render_template('index.html', name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2)
		
			

				elif(acc == row[2] and pas == row[3] and row[9]=="manager" and row[8]=="0" ):
						f = 0
						session['user'] = request.form['account']
						session['manager'] = row[9]
						sqlstr = "UPDATE PERSONAL SET online={} WHERE account='{}'".format(1,row[2])
						conn.execute(sqlstr)
						conn.commit()
						purchase.set_User_accouent(row[0])
						print("2")
						return render_template('manager_index.html', name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2)
			if(f == 1):
				return render_template('login.html',mes="wrong")
			else:
				return render_template('login.html',mes="wrong1")
		
		if request.values.get('var')=='登出':
			acc = request.values['acc']
			sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,acc) 
			conn.execute(sqlstr)
			conn.commit()
			session.clear
			return render_template('index.html',acc="")
	if session.get('user')!=" ":
			
		for row in rows:
			if session.get('user') == row[2] and row[9]=="custom" and row[8]=="1":
				purchase.set_User_accouent(row[0])
				print(row[8])
				print("3")
				return render_template('index.html', name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2)
			if session.get('user') == row[2] and row[9]=="manager" and row[8]=="1":
				purchase.set_User_accouent(row[0])
				print("4")
				return render_template('manager_index.html',name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2)
			if session.get('user') == row[2] and row[8]==0:
				return render_template('index.html',acc="")
	return render_template('index.html',acc="")
	conn.close()

 
#登出畫面
@app.route('/logout', methods=['GET','POST'])
def logout():
	conn = sqlite3.connect('personal.sqlite')
	conn1 = sqlite3.connect('news.sqlite')
	cursor = conn.execute("select * from PERSONAL")
	cursor1=conn1.execute("select * from NEWS")
	rownews = cursor1.fetchall()
	rows = cursor.fetchall()
	n = 0
	count = 0
	for rownew in rownews:
		count = count +1
	
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	for row in rows:
		if request.method =='GET':
			if session.get('user')!= " ":
				if session.get('user')==row[2]:
					sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,row[2]) 
					conn.execute(sqlstr)
					conn.commit()
					print("FUCK")
					session.clear
					return redirect(url_for('index'))


#修改密碼
@app.route('/chps', methods=['GET','POST'])
def chps():
	conn = sqlite3.connect('personal.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	rows = cursor.fetchall()
	conn1 = sqlite3.connect('news.sqlite')
	cursor1=conn1.execute("select * from NEWS")
	rownews = cursor1.fetchall()
	
	n = 0
	count = 0
	for rownew in rownews:
		count = count +1
	
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	for row in rows:
		if session.get('user') != "":
			if request.method =='POST':
				if request.values['var']=='登出':
					acc = request.values['acc']
					sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,acc) 
					conn.execute(sqlstr)
					conn.commit()
					
					
					session.clear
					return redirect(url_for('index')) 
				if request.values['var']=='送出':
					opass = request.values['old_pass']
					npass =request.values['new_pass']
					npass1=request.values['new1_pass']
					for row1 in rows:
						if row1[2]==session.get('user') and row1[3]== opass:
							if npass == npass1 and npass1 !=row1[3]:
								sqlstr="UPDATE PERSONAL SET password='{}' WHERE account='{}'".format(npass,row1[2])
								conn.execute(sqlstr)
								conn.commit()
								purchase.set_User_accouent(row[0])
								return render_template('index.html',name=row1[1],acc=row1[2],email=row1[4],phone=row1[5],floor=row1[6],roomno=row1[7],addr=purchase.get_addrress())
							else:
    								return render_template('chps.html',mes='wrong')
						else:
    							return render_template('chps.html',mes='wrong1')

		if request.method == 'GET':
				if session.get('user') == row[2]:
					purchase.set_User_accouent(row[0])
					return render_template('chps.html',name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2)


#公告介面
@app.route('/news', methods=['GET','POST'])
def news():
	conn = sqlite3.connect('personal.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	rows = cursor.fetchall()
	conn1 = sqlite3.connect('news.sqlite')
	cursor1=conn1.execute("select * from NEWS")
	rownews = cursor1.fetchall()
	
	n = 0
	count = 0
	for rownew in rownews:
		count = count +1
	
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	for row in rows:
		if session.get('user') != "":
			if request.method =='POST':
				if request.values['var']=='登出':
					
					sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,session.get('user')) 
					conn.execute(sqlstr)
					conn.commit()
					print(row[8])
					session.pop('user',None)
					print(session.get('user'))
					return redirect(url_for('index')) 
			if request.method=="GET":
				if session.get('user') == row[2]:
					
					count = 0
					a=[]
					for rownew in rownews:
						count = count+1
					
						string=str('<a herf=""><div class="box"><div class="headimage news1"></div><p class="lefttitle"><a href={}>{}</p></div></a>'.format(url_for('newcontent',no=rownew[0]),rownew[1]))
						a.append(string)
						
					for i in a:
						purchase.set_User_accouent(row[0])
						print(a)
						return render_template('listNews.html',text="<br>".join(str(i) for i in a),name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2)
		else:
			
			return render_template("index.html",acc="")

#公告連結1	
@app.route('/newscontent1', methods=['GET','POST'])
def newcontent1():
	conn = sqlite3.connect('personal.sqlite')
	conn1 = sqlite3.connect('news.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	cursor1=conn1.execute("select * from NEWS")
	rows = cursor.fetchall()
	rownews = cursor1.fetchall()
	n = 0
	count = 0
	for rownew in rownews:
		count = count +1
	
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	for row in rows:
		if session.get('user') != "":
			if request.method =='POST':
				if request.values['var']=='登出':
					
					sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,session.get('user')) 
					conn.execute(sqlstr)
					conn.commit()
					
					session.pop('user',None)
					
					return redirect(url_for('index')) 
			if request.method =='GET':
				if session.get('user') == row[2]:
					count = 0
					n = 0
					for rownew in rownews:
						count=count+1
					for rownew in rownews:
						n=n+1
						
						if count == n:
							purchase.set_User_accouent(row[0])
							return render_template('news.html',name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2,title=rownew[1],content=rownew[2])
						
		else:
			return render_template('news.html',acc="")
	
#公告連結2
@app.route('/newscontent2', methods=['GET','POST'])
def newcontent2():
	conn = sqlite3.connect('personal.sqlite')
	conn1 = sqlite3.connect('news.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	cursor1=conn1.execute("select * from NEWS")
	rows = cursor.fetchall()
	rownews = cursor1.fetchall()
	
	n = 0
	count = 0
	for rownew in rownews:
		count = count +1
	
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	for row in rows:
		if session.get('user') != "":
			if request.method =='POST':
				if request.values['var']=='登出':
					
					sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,session.get('user')) 
					conn.execute(sqlstr)
					conn.commit()
					
					session.pop('user',None)
					
					return redirect(url_for('index')) 
			if request.method =='GET':
				if session.get('user') == row[2]:
					count = 0
					n = 0
					for rownew in rownews:
						count=count+1
						
					count = count -1
					print(count)
					for rownew in rownews:
						n=n+1
						
						if count == n:
							
							purchase.set_User_accouent(row[0])
							return render_template('news.html',name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2,title=rownew[1],content=rownew[2])
						
		else:
			return render_template('news.html',acc="")

#公告連結3
@app.route('/newscontent3', methods=['GET','POST'])
def newcontent3():
	conn = sqlite3.connect('personal.sqlite')
	conn1 = sqlite3.connect('news.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	cursor1=conn1.execute("select * from NEWS")
	rows = cursor.fetchall()
	rownews = cursor1.fetchall()
	
	n = 0
	count = 0
	for rownew in rownews:
		count = count +1
	
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	for row in rows:
		if session.get('user') != "":
			if request.method =='POST':
				if request.values['var']=='登出':
					
					sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,session.get('user')) 
					conn.execute(sqlstr)
					conn.commit()
					print(row[8])
					session.pop('user',None)
					print(session.get('user'))
					return redirect(url_for('index')) 
			if request.method =='GET':
				if session.get('user') == row[2]:
					count = 0
					n = 0
					for rownew in rownews:
						count=count+1
						
					count = count -2
					print(count)
					for rownew in rownews:
						n=n+1
						
						if count == n:
							
							purchase.set_User_accouent(row[0])
							return render_template('news.html',name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2,title=rownew[1],content=rownew[2])
						else:
    						
							return render_template('news.html',name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3="none",title=rownew[1],content=rownew[2])
						
		else:
			return render_template('news.html',acc="")



#租借功能
@app.route('/rent', methods=['GET','POST'])
def rent():
	conn = sqlite3.connect('personal.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	rows = cursor.fetchall()
	conn1 = sqlite3.connect('news.sqlite')
	cursor1=conn1.execute("select * from NEWS")
	rownews = cursor1.fetchall()
	conn2 = sqlite3.connect('rent.sqlite')
	cursor2=conn2.execute("select * from RENT")
	rowrents = cursor2.fetchall()
	n = 0
	count = 0
	rent_max=0
	for rownew in rownews:
		count = count +1
	for rowrent in rowrents:
    		rent_max = rent_max+1
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	for row in rows:
		if session.get('user') != "":
			if request.method =='POST':
				if session.get('user') == row[2]:
					if request.values.get('var')=='送出':
						rent_date = request.values['date']
						rent_time = request.values['time']
						rent_time2 = request.values['time2']
						rent_item = request.values['item']
						key=request.values['private_key']

						if rent_date=="" or rent_time=="" or key=="" :
							purchase.set_User_accouent(row[0])
							return render_template('rent.html',error=True,name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2)
						else:
							rent_time2=int(rent_time2)
							purchase.set_User_time(rent_time2)
							purchase.set_User_key(key)
							truffle_return=purchase.transaction()
							tx_hash=purchase.get_hash()
							if truffle_return=="Error":
								purchase.set_User_accouent(row[0])
								
								return render_template('rent.html',error=True,name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2)
							else:
								purchase.set_User_accouent(row[0])
								sqlstr="insert into RENT(no,date,time,time2,item,customer,name,phone,hash) values ({},'{}','{}','{}','{}','{}','{}','{}','{}')".format(rent_max+1,rent_date,rent_time,rent_time2,rent_item,row[7],row[1],row[5],tx_hash)
								conn2.execute(sqlstr)
								conn2.commit()
								return render_template('rent_message.html',name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2,rent_date=rent_date,rent_time=rent_time,rent_name=row[1],rent_phone=row[5],rent_item=rent_item,sys_time=time.ctime(time.time()),rent_time2=rent_time2)
				
					if request.values['var']=='登出':
					
						sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,session.get('user')) 
						conn.execute(sqlstr)
						conn.commit()
						print(row[8])
						session.pop('user',None)
						print(session.get('user'))
						return redirect(url_for('index')) 
			if request.method =='GET':
				if session.get('user') == row[2]:
					purchase.set_User_accouent(row[0])
					return render_template('rent.html',name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2,rent_balance=purchase.get_balance())
			
		else:
			return render_template('index.html')


#租借訊息
@app.route('/rentmessage', methods=['GET','POST'])
def rentmessage():
	conn = sqlite3.connect('personal.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	rows = cursor.fetchall()
	conn1 = sqlite3.connect('news.sqlite')
	cursor1=conn1.execute("select * from NEWS")
	rownews = cursor1.fetchall()
	
	n = 0
	count = 0
	for rownew in rownews:
		count = count +1
	
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	for row in rows:
		if session.get('user') != "":
			if request.method =='GET':
				if session.get('user') == row[2]:
						purchase.set_User_accouent(row[0])
						return render_template('rent_message.html',name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2,rent_balance=purchase.get_balance())

			if request.method =='POST':
				if request.values['var']=='登出':
					
					sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,session.get('user')) 
					conn.execute(sqlstr)
					conn.commit()
					print(row[8])
					session.pop('user',None)
					print(session.get('user'))
					return redirect(url_for('index')) 

			
		else:
			return render_template('rentmessage.html')
#取得包裹
@app.route('/packet', methods=['GET','POST'])
def packet():
	conn = sqlite3.connect('personal.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	rows = cursor.fetchall()
	conn1 = sqlite3.connect('news.sqlite')
	cursor1=conn1.execute("select * from NEWS")
	rownews = cursor1.fetchall()
	conn2 = sqlite3.connect('packet.sqlite')
	cursor2 = conn2.execute("select * from PACKETS")
	rowpacs = cursor2.fetchall()
	
	n = 0
	count = 0
	for rownew in rownews:
		count = count +1
	
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	for row in rows:
		if session.get('user') != "":
			if request.method =='POST':
				if request.values['var']=='登出':
					
					sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,session.get('user')) 
					conn.execute(sqlstr)
					conn.commit()
					print(row[8])
					session.pop('user',None)
					print(session.get('user'))
					return redirect(url_for('index')) 
			if request.method=="GET":
				if session.get('user') == row[2]:
					purchase.set_User_accouent(row[0])
					
					count = 0
					a=[]
					for rowpac in rowpacs:
						count = count+1
						if row[7] == rowpac[1]:
							string=str('<a herf=""><div class="box"><div class="headimage"></div><p class="lefttitle"><a href={}>日期：{}</p></div></a>'.format(url_for('packetcontent',no=rowpac[0]),rowpac[3]))
							a.append(string)
						
					for i in a:
						if a != None:	
							purchase.set_User_accouent(row[0])
						
							return render_template('listPacket.html',text="<br>".join(str(i) for i in a),name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2)
						else:
							purchase.set_User_accouent(row[0])
							return render_template('listPacket.html',text="<BR>沒有包裹",name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2)
		else:
			
			return render_template("index.html",acc="")
#包裹內容
@app.route('/packetscontent/<no>', methods=['GET','POST'])
def packetcontent(no):
	conn = sqlite3.connect('personal.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	rows = cursor.fetchall()

	conn1 = sqlite3.connect('news.sqlite')
	cursor1=conn1.execute("select * from NEWS")
	rownews = cursor1.fetchall()
	conn2 = sqlite3.connect('packet.sqlite')
	cursor2=conn2.execute("select * from PACKETS")
	rowpacs = cursor2.fetchall()
	n = 0
	
	count = 0
	for rownew in rownews:
		count = count +1
	
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	for row in rows:
		if session.get('user') != "":
			if request.method =='POST':
				if request.values['var']=='登出':
					
					sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,session.get('user')) 
					conn.execute(sqlstr)
					conn.commit()
					print(row[8])
					session.pop('user',None)
					print(session.get('user'))
					purchase.set_User_accouent(row[0])
					return redirect(url_for('index')) 
							
			if request.method =='GET':
				if session.get('user') == row[2]:
						for rowpac in rowpacs:
							if int(no) == rowpac[0]:
								purchase.set_User_accouent(row[0])
								return render_template('packet.html',name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2,title=rowpac[1],content=rowpac[2])
							
		else:
			for rownew in rownews:
				if int(no) == rownew[0]:
					return render_template('packet.html',title=rownew[1],content=rownew[2])

#公告內容		
@app.route('/newscontent/<no>', methods=['GET','POST'])
def newcontent(no):
	conn = sqlite3.connect('personal.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	rows = cursor.fetchall()
	conn1 = sqlite3.connect('news.sqlite')
	cursor1=conn1.execute("select * from NEWS")
	rownews = cursor1.fetchall()
	n = 0
	
	count = 0
	for rownew in rownews:
		count = count +1
	
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	for row in rows:
		if session.get('user') != "":
			if request.method =='POST':
				if request.values['var']=='登出':
					
					sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,session.get('user')) 
					conn.execute(sqlstr)
					conn.commit()
					print(row[8])
					session.pop('user',None)
					print(session.get('user'))
					purchase.set_User_accouent(row[0])
					return redirect(url_for('index')) 
							
			if request.method =='GET':
				if session.get('user') == row[2]:
						for rownew in rownews:
							if int(no) == rownew[0]:
								purchase.set_User_accouent(row[0])
								return render_template('news.html',name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2,title=rownew[1],content=rownew[2])
							
		else:
			for rownew in rownews:
				if int(no) == rownew[0]:
					return render_template('news.html',title=rownew[1],content=rownew[2])
#修改個資
@app.route('/personal' , methods=['GET','POST'])
def personal():
	conn = sqlite3.connect('personal.sqlite')
	conn1 = sqlite3.connect('packet.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	cursor1=conn1.execute("select * from PACKETS")
	rows = cursor.fetchall()
	conn2 = sqlite3.connect('news.sqlite')
	cursor2=conn2.execute("select * from NEWS")
	rownews = cursor2.fetchall()
	rowpacs = cursor1.fetchall()
	n = 0
	count = 0
	for rownew in rownews:
		count = count +1
	
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	for row in rows:
		if session.get('user') != "":
			if request.method =='GET':
				if session.get('user') == row[2]:
					purchase.set_User_accouent(row[0])
					return render_template('personal.html',name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2)
			if request.method == 'POST':
				if session.get('user') == row[2]:
					if request.values['var']=='登出':
						
						sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,session.get('user')) 
						conn.execute(sqlstr)
						conn.commit()
						session.pop('user',None)
						return redirect(url_for('index')) 
					if request.values['var']=='送出':
						
						email =  request.values['email']
						phone =  request.values['phone']
						
						
						
						sqlstr  = "UPDATE PERSONAL SET email='{}',phone='{}' WHERE account='{}'".format(email,phone,row[2])
						conn.execute(sqlstr)
						conn.commit()
						return redirect(url_for('index'))
				
					
		else:
			return render_template('personal.html.html')


#管理者首頁

#上傳包裹
@app.route('/managerpacket', methods=['GET','POST'])
def managerpacket():
	conn = sqlite3.connect('personal.sqlite')
	conn1 = sqlite3.connect('packet.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	cursor1=conn1.execute("select * from PACKETS")
	rows = cursor.fetchall()
	conn2 = sqlite3.connect('news.sqlite')
	cursor2=conn2.execute("select * from NEWS")
	rownews = cursor2.fetchall()
	rowpacs = cursor1.fetchall()
	a=[]
	n = 0
	count = 0
	pac_max=0
	for rownew in rownews:
		count = count +1
	for rowpac in rowpacs:
    		pac_max=pac_max+1
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	for row in rows:
		if session.get('user') != "":
			if request.method =='GET':
				if session.get('user') == row[2]:
					
						purchase.set_User_accouent(row[0])
						return render_template('manager_packetUp.html',text="".join(str(i) for i in a),name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2,count=pac_max+1)
			if request.method == 'POST':
				if request.values['var']=='登出':
					
					sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,session.get('user')) 
					conn.execute(sqlstr)
					conn.commit()
					print(row[8])
					session.pop('user',None)
					print(session.get('user'))
					return redirect(url_for('index')) 
				if request.values['var']=='送出':
					packetnumber =  pac_max+1
					customnumber =  request.values['customnumber']
					content = request.values['content']
					date = time.strftime("%Y/%m/%d", time.localtime())
					if packetnumber!=None and customnumber!=None and content!=None:
						sqlstr  = "insert into PACKETS(packetnumber,customnumber,content,date) values ({},'{}','{}','{}')".format(packetnumber,customnumber,content,date)
						conn1.execute(sqlstr)
						conn1.commit()
						return render_template("manager_index.html")
					else:
						return render_template("manager_packetUp.html",mes="wrong")
		else:
			return render_template('manager_packetUp.html')		
#編輯包裹
@app.route('/managerpacketed/<no>', methods=['GET','POST'])
def managerpacketed(no):
	conn = sqlite3.connect('personal.sqlite')
	conn1 = sqlite3.connect('packet.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	cursor1=conn1.execute("select * from PACKETS")
	rows = cursor.fetchall()
	conn2 = sqlite3.connect('news.sqlite')
	cursor2=conn2.execute("select * from NEWS")
	rownews = cursor2.fetchall()
	rowpacs = cursor1.fetchall()
	n = 0
	count = 0
	for rownew in rownews:
		count = count +1
	
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	for row in rows:
		if session.get('user') != "":
			if request.method =='GET':
				if session.get('user') == row[2]:
					purchase.set_User_accouent(row[0])
					for rowpac in rowpacs:
						if int(no) == rowpac[0]:
							return render_template('manager_editor_pac.html',name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2,no=rowpac[0],title=rowpac[1],content=rowpac[2])
			if request.method == 'POST':
				if request.values['var']=='登出':
					
					sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,session.get('user')) 
					conn.execute(sqlstr)
					conn.commit()
					print(row[8])
					session.pop('user',None)
					print(session.get('user'))
					return redirect(url_for('index')) 
				if request.values['var']=='送出':
					packetnumber =  request.values['packetnumber']
					customnumber =  request.values['customnumber']
					content = request.values['content']
					date = time.strftime("%Y/%m/%d", time.localtime())
					if packetnumber!=None and customnumber!=None and content!=None:
						for rownew in rownews:
							if int(no) == rownew[0]:
								sqlstr  = "UPDATE PACKETS SET customnumber='{}',content='{}',date='{}' WHERE packetnumber={}".format(customnumber,content,date,packetnumber)
								conn1.execute(sqlstr)
								conn1.commit()
								return redirect(url_for('index')) 
						
					else:
						return render_template("manager_editor_pac.html",mes="wrong")
		else:
			return render_template('manager_editor_pac.html.html')		
#上傳公告
@app.route('/managernewup', methods=['GET','POST'])
def managernewup():
	conn = sqlite3.connect('personal.sqlite')
	conn1 = sqlite3.connect('news.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	cursor1=conn1.execute("select * from NEWS")
	rows = cursor.fetchall()
	rownews = cursor1.fetchall()
	
	n = 0
	count = 0
	for rownew in rownews:
		count = count +1
	
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	for row in rows:
		if session.get('user') != "":
			if request.method =='GET':
				
				if session.get('user') == row[2]:
					purchase.set_User_accouent(row[0])
					return render_template('manager_newsUp.html',name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2,count=count+1)
			if request.method == 'POST':
				if request.values['var']=='登出':
					
					sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,session.get('user')) 
					conn.execute(sqlstr)
					conn.commit()
					print(row[8])
					session.pop('user',None)
					print(session.get('user'))
					return redirect(url_for('index')) 
				if request.values['var']=='送出':
					no =  count+1
					title =  request.values['title']
					content = request.values['content']
					date = time.strftime("%Y/%m/%d", time.localtime())
					if no!=None and title!=None and content!=None:
						sqlstr  = "insert into NEWS(no,title,content,date) values ({},'{}','{}','{}')".format(no,title,content,date)
						conn1.execute(sqlstr)
						conn1.commit()
						return render_template("manager_index.html")
					else:
						return render_template("manager_newsUp.html",mes="wrong")
		else:
			return render_template('manager_newsUp.html')

#公告編輯
@app.route('/editornew/<no>', methods=['GET','POST'])
def editornew(no):
	conn = sqlite3.connect('personal.sqlite')
	conn1 = sqlite3.connect('news.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	cursor1=conn1.execute("select * from NEWS")
	rows = cursor.fetchall()
	rownews = cursor1.fetchall()
	
	n = 0
	count = 0
	for rownew in rownews:
		count = count +1
	
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	for row in rows:
		if session.get('user') != "":
			if request.method =='GET':
				if session.get('user') == row[2]:
					purchase.set_User_accouent(row[0])
					
					for rownew in rownews:
						if int(no) == rownew[0]:
							return render_template('manager_editor.html',name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2,no=rownew[0],title=rownew[1],content=rownew[2])
					
				else:
					return "wrong"
			if request.method == 'POST':
				if request.values['var']=='登出':
					
					sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,session.get('user')) 
					conn.execute(sqlstr)
					conn.commit()
					print(row[8])
					session.pop('user',None)
					print(session.get('user'))
					return redirect(url_for('index')) 
				if request.values['var']=='送出':
					no =  request.values['no']
					title =  request.values['title']
					content = request.values['content']
					date = time.strftime("%Y/%m/%d", time.localtime())
					for rownew in rownews:
						if int(no) == rownew[0]:
							sqlstr  = "UPDATE NEWS SET title='{}',content='{}',date='{}' WHERE no={}".format(title,content,date,no)
							conn1.execute(sqlstr)
							conn1.commit()
							return redirect(url_for('index')) 
					else:
						return render_template("manager_editor.html",mes="wrong")
				
				if session.get('user') == row[2]:
					purchase.set_User_accouent(row[0])
					for rownew in rownews:
						if no == rownew[0]:
							return render_template('manager_editor.html',name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2,no=rownew[0],title=rownew[1],content=rownew[2])
		else:
			return render_template('manager_editor.html')
#編輯個資
@app.route('/managernewed/<no>', methods=['GET','POST'])
def managernewed(no):
	conn = sqlite3.connect('personal.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	rows = cursor.fetchall()
	conn1 = sqlite3.connect('news.sqlite')
	cursor1=conn1.execute("select * from NEWS")
	rownews = cursor1.fetchall()
	
	n = 0
	count = 0
	max=0
	for row in rows:
		max = max +1
	for rownew in rownews:
		count = count +1
	
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	for row in rows:
		if session.get('user') != "":
			
			if request.method =='GET':
				if session.get('user') == row[2]:
					name = row[1]
					acc = row[2]
					email=row[4]
					phone=row[5]
					floor=row[6]
					roomno=row[7]
					addr=purchase.get_addrress()
					for row in rows:
						if int(no) == row[0]:
							purchase.set_User_accouent(row[0])
							return render_template('manager_editor_person.html',name=name,acc=acc,email=email,phone=phone,floor=floor,roomno=roomno,new1=new,new2=new1,new3=new2,_name=row[1],_acc=row[2],_email=row[4],_phone=row[5],_floor=row[6],_roomno=row[7],addr=purchase.get_addrress())
			if request.method =='POST':
				if request.values['var']=='登出':
					
					sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,session.get('user')) 
					conn.execute(sqlstr)
					conn.commit()
					print(row[8])
					session.pop('user',None)
					print(session.get('user'))
					return redirect(url_for('index')) 
				if request.values['var']=='確認':
					name = request.values['name']
					roomno = request.values['roomno']
					floor = request.values['floor']
					phone = request.values['phone']
					email = request.values['email']
					
					if name!=None and roomno!= None and floor != None and email!=None :
						for row in rows:
							if int(no) == row[0]:
								sqlstr="UPDATE PERSONAL SET name='{}',roomno='{}',phone='{}',floor='{}',email='{}' WHERE no={}".format(name,roomno,phone,floor,email,int(no))
								conn.execute(sqlstr)
								conn.commit()	
								return redirect(url_for('index'))
					else:
						return render_template("manager_editor_person.html",mes="wrong")
				else:
					if session.get('user') == row[2]:
						purchase.set_User_accouent(row[0])
						return render_template('manager_editor_person.html',name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2)
		else:

			return render_template('manager_editor_person.html')

#新增用戶		
@app.route('/managernew', methods=['GET','POST'])
def managernew():
	conn = sqlite3.connect('personal.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	rows = cursor.fetchall()
	conn1 = sqlite3.connect('news.sqlite')
	cursor1=conn1.execute("select * from NEWS")
	rownews = cursor1.fetchall()
	
	n = 0
	count = 0
	max=0
	for row in rows:
		max = max +1
	for rownew in rownews:
		count = count +1
	
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	for row in rows:
		if session.get('user') != "":
			if request.method =='GET':
				if session.get('user') == row[2]:
					purchase.set_User_accouent(row[0])
					return render_template('manager_newmember.html',name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2)
			if request.method =='POST':
				if request.values['var']=='登出':
					
					sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,session.get('user')) 
					conn.execute(sqlstr)
					conn.commit()
					print(row[8])
					session.pop('user',None)
					print(session.get('user'))
					return redirect(url_for('index')) 
				if request.values['var']=='新增':
					name = request.values['name']
					roomno = request.values['roomno']
					floor = request.values['floor']
					phone = request.values['phone']
					email = request.values['email']
					account = request.values['account']
					password = request.values['password']
					if name!=None and roomno!= None and floor != None and email!=None and account!=None and password!=None:
						sqlstr="insert into PERSONAL(no,name,roomno,phone,floor,email,account,password) values ({},'{}','{}','{}','{}','{}','{}','{}')".format(max,name,roomno,phone,floor,email,account,password)
						conn.execute(sqlstr)
						conn.commit()	
						return render_template("manager_index.html")
					else:
						return render_template("manager_newmember.html",mes="wrong")
				else:
					if session.get('user') == row[2]:
						purchase.set_User_accouent(row[0])
						return render_template('manager_newmember.html',name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2)
		else:

			return render_template('manager_newmember.html')
		
#管理包裹
@app.route('/managerlistpacket', methods=['GET','POST'])
def managerlistpacket():
	conn = sqlite3.connect('personal.sqlite')
	conn1 = sqlite3.connect('packet.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	cursor1=conn1.execute("select * from PACKETS")
	rows = cursor.fetchall()
	rowpacs = cursor1.fetchall()

	conn2 = sqlite3.connect('news.sqlite')
	cursor2=conn2.execute("select * from NEWS")
	rownews = cursor2.fetchall()
	
	n = 0
	count = 0
	for rownew in rownews:
		count = count +1
	
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	for row in rows:
		for row in rows:
			if session.get('user') != "":
				if request.method =='GET':
					if session.get('user') == row[2]:
							count = 0
							a=[]
							for rowpac in rowpacs:
								count = count+1
							#string是你從sql拉出來的東西
								string=str('<div class="absolute"><p class="title"><tr><td>{}</td><td><a href={}>{}</td><td>{}</td><td>{}</td></tr></p></div>'.format(rowpac[0],url_for('managerpacketed',no=rowpac[0]),rowpac[1],rowpac[2],rowpac[3]))
								a.append(string)
								#return寫的是回傳list的值 中間插入<br>(換行)
								#print(te.put_str_inlist(string,count))
								#return("<br>".join(str(i) for i in te.put_str_inlist(string,count)))
							for i in a:
								#print(i)
								purchase.set_User_accouent(row[0])
								return render_template('manager_package2.html',text="".join(str(i) for i in a),name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2)
						
				if request.method =='POST':
					if request.values['var']=='登出':
					
						sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,session.get('user')) 
						conn.execute(sqlstr)
						conn.commit()
						print(row[8])
						session.pop('user',None)
						print(session.get('user'))
						return redirect(url_for('index')) 
					if request.values['var']=='確認':
						no = request.values['name']
						sqlstr="DELETE FROM PACKETS WHERE packetnumber ={}".format(int(no))
						conn1.execute(sqlstr)
						conn1.commit()
						return redirect(url_for('index')) 
			else:
			
				return render_template('index.html')
#管理公告
@app.route('/managerlistnew', methods=['GET','POST'])
def managerlistnew():
	conn = sqlite3.connect('personal.sqlite')
	conn1 = sqlite3.connect('news.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	cursor1=conn1.execute("select * from NEWS")
	rows = cursor.fetchall()
	rownews = cursor1.fetchall()
	
	n = 0
	count = 0
	for rownew in rownews:
		count = count +1
	
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	for row in rows:
		if session.get('user') != "":
			if request.method =='GET':
				if session.get('user') == row[2]:
							count = 0
							a=[]
							for rownew in rownews:
								count = count+1
							
								string=str('<p class="title"><tr><td>{}</td><td><a href={}>{}</td><td>{}</td></tr></p>'.format(rownew[0],url_for('editornew',no=rownew[0]),rownew[1],rownew[2]))
								a.append(string)
								
							for i in a:
								purchase.set_User_accouent(row[0])
								return render_template('manager_managerment.html',text="".join(str(i) for i in a),name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2)
								
			if request.method =='POST':
				if request.values['var']=='登出':
					
					sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,session.get('user')) 
					conn.execute(sqlstr)
					conn.commit()
					print(row[8])
					session.pop('user',None)
					print(session.get('user'))
					return redirect(url_for('index')) 
				if request.values['var']=='確認':
						no = request.values['name']
						sqlstr="DELETE FROM NEWS WHERE no ={}".format(int(no))
						conn1.execute(sqlstr)
						conn1.commit()
						return redirect(url_for('index')) 
				if session.get('user') == row[2]:
					for rownew in rownews:
						purchase.set_User_accouent(row[0])
						return render_template('manager_managerment.html',name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2)
		else:
			return render_template('manager_managerment.html')

#成員資訊
@app.route('/managerperson', methods=['GET','POST'])
def managerperson():
	conn = sqlite3.connect('personal.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	rows = cursor.fetchall()
	conn1 = sqlite3.connect('news.sqlite')
	cursor1=conn1.execute("select * from NEWS")
	rownews = cursor1.fetchall()
	
	n = 0
	count = 0
	for rownew in rownews:
		count = count +1
	
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	
	for row in rows:
		if session.get('user') != "":
			if request.method =='GET':
				if session.get('user') == row[2]:
					count = 1
					a=[]
					for row1 in rows:
						count = count+1
				
						string=str('<div class="absolute"><p class="title"><tr><td>{}</td><td><a href={}>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td></tr></p></div>'.format(row1[0],url_for('managernewed',no=row1[0]),row1[1],row1[5],row1[4],row1[6],row1[7]))
						a.append(string)
						
					purchase.set_User_accouent(row[0])
					return render_template('manager_person.html',text="".join(str(i) for i in a),name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2)
			if request.method =='POST':
				if request.values['var']=='登出':
				
					sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,session.get('user')) 
					conn.execute(sqlstr)
					conn.commit()
					print(row[8])
					session.pop('user',None)
					print(session.get('user'))
					return redirect(url_for('index')) 
				if request.values['var']=='確認':
			
					no = request.values['name']
					sqlstr="DELETE FROM PERSONAL WHERE no ={}".format(int(no))
					conn.execute(sqlstr)
					conn.commit()
					return redirect(url_for('index')) 
			else:
				return render_template('manager_person.html')

#管理租借
@app.route('/managerrent', methods=['GET','POST'])
def managerrent():
	conn = sqlite3.connect('personal.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	rows = cursor.fetchall()
	conn1 = sqlite3.connect('news.sqlite')
	cursor1=conn1.execute("select * from NEWS")
	rownews = cursor1.fetchall()
	conn2 = sqlite3.connect('rent.sqlite')
	cursor2=conn2.execute("select * from RENT")
	rowrents = cursor2.fetchall()

	n = 0
	count = 0
	rent_max = 0
	for rownew in rownews:
		count = count +1
	for rowrent in rowrents:
			rent_max= rent_max +1
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	
	for row in rows:
		if session.get('user') != "":
			if request.method =='GET':
				if session.get('user') == row[2]:
					count = 1
					a=[]
					for rowrent in rowrents:
						string=str('<div class="absolute"><p class="title"><tr><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td><a href="{}" class="text">詳情</a></td>	</tr></p></div>'.format(rowrent[0],rowrent[5],rowrent[4],rowrent[1],url_for('managerrentmessage',no=rowrent[0])))
						a.append(string)
						
					for i in a:
						purchase.set_User_accouent(row[0])
						return render_template('manager_rent.html',text="".join(str(i) for i in a),name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2)
			if request.method =='POST':
				if request.values['var']=='登出':
				
					sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,session.get('user')) 
					conn.execute(sqlstr)
					conn.commit()
					print(row[8])
					session.pop('user',None)
					print(session.get('user'))
					return redirect(url_for('index')) 
				if request.values['var']=='確認':
			
					no = request.values['name']
					sqlstr="DELETE FROM PERSONAL WHERE no ={}".format(int(no))
					conn.execute(sqlstr)
					conn.commit()
					return redirect(url_for('index')) 
			else:
				return render_template('manager_rent.html')

#租借訊息
@app.route('/managerrentmessage/<no>', methods=['GET','POST'])
def managerrentmessage(no):
	conn = sqlite3.connect('personal.sqlite')
	cursor=conn.execute("select * from PERSONAL")
	rows = cursor.fetchall()
	conn1 = sqlite3.connect('news.sqlite')
	cursor1=conn1.execute("select * from NEWS")
	rownews = cursor1.fetchall()
	conn2 = sqlite3.connect('rent.sqlite')
	cursor2=conn2.execute("select * from RENT")
	rowrents = cursor2.fetchall()

	n = 0
	count = 0
	rent_max = 0
	for rownew in rownews:
		count = count +1
	for rowrent in rowrents:
			rent_max= rent_max +1
	for rownew in rownews:
		n = n +1
		if count == n:
			new = rownew[1]
		if count-1 == n:
			new1 = rownew[1]
		if count-2 == n:
			new2 = rownew[1]
	
	for row in rows:
		if session.get('user') != "":
			if request.method =='GET':
				if session.get('user') == row[2]:
					count = 1
					for rowrent in rowrents:
						if int(no) == rowrent[0]:
							purchase.set_User_accouent(row[0])
							purchase.get_transactions(rowrent[8])
							return render_template('rent_message2.html',name=row[1],acc=row[2],email=row[4],phone=row[5],floor=row[6],roomno=row[7],addr=purchase.get_addrress(),new1=new,new2=new1,new3=new2,rent_date=rowrent[1],rent_time=rowrent[2],rent_time2=rowrent[3],rent_name=rowrent[6],rent_phone=rowrent[7],rent_item=rowrent[4])
			if request.method =='POST':
				if request.values['var']=='登出':
				
					sqlstr="UPDATE PERSONAL SET online={} WHERE account='{}'".format(0,session.get('user')) 
					conn.execute(sqlstr)
					conn.commit()
					print(row[8])
					session.pop('user',None)
					print(session.get('user'))
					return redirect(url_for('index')) 
				if request.values['var']=='確認':
			
					no = request.values['name']
					sqlstr="DELETE FROM PERSONAL WHERE no ={}".format(int(no))
					conn.execute(sqlstr)
					conn.commit()
					return redirect(url_for('index')) 
			else:
				return render_template('rent_message2.html')

if __name__ == '__main__':
	app.run(host='120.110.113.91',port='9545',debug=True)