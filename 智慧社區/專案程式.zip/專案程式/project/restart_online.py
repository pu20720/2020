
#import purchase as purchase
import sqlite3
import time
import os

conn = sqlite3.connect('personal.sqlite')
cursor=conn.execute("select * from PERSONAL")
rows = cursor.fetchall()
max = 0
for row in rows:
    max = max+1
for row in rows:
    sqlstr = "UPDATE PERSONAL SET online='{}' WHERE account='{}'".format(0,row[2])
    print(sqlstr)
    conn.execute(sqlstr)
    conn.commit()
conn.close()
