from flask import Flask
import sqlite3
import test_return as te
app=Flask(__name__)
@app.route('/')
def googlelink():

    conn = sqlite3.connect('personal.sqlite')
    cursor = conn.execute("select * from PERSONAL")
    rows = cursor.fetchall()
    count = 0
    a=[]
    for row in rows:
        count = count+1
    #string是你從sql拉出來的東西
        string=str('<div ><p>{}  {}  {}  {}  {}</p></div>'.format(row[2],row[5],row[6],row[7],row[8]))
        a.append(string)
        #return寫的是回傳list的值 中間插入<br>(換行)
        #print(te.put_str_inlist(string,count))
        #return("<br>".join(str(i) for i in te.put_str_inlist(string,count)))
    for i in a:
            #print(i)
            return("<br>".join(str(i) for i in a))
            
if __name__ == '__main__':
	app.run(host='127.0.0.1',port='5000',debug=True)   