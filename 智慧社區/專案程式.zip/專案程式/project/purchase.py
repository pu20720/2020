from web3 import Web3
import json
import logging
import sqlite3
import os
import json

#取得區塊鏈鏈結
w3 = Web3(Web3.HTTPProvider('http://localhost:8545'))

#取得使用者帳號
accounts = w3.eth.accounts
address = ""
key=""
balance=0
ETH=balance/1000000000000000000
set_time=0
tx_hash=""


#-----------------functions--------------------

#取得使用者帳號資料(從資料庫匯入使用者代號)
def set_User_accouent(n):
    global address,balance,ETH
    address=accounts[n]
    balance = w3.eth.getBalance(address)
    ETH=balance/1000000000000000000
#address = accounts[1]#用帳戶1測試

#從網站取得key
def set_User_key(_key):
    global key
    key=_key
#key = "75448ea88b1dbb31c167f051a31e6d024b9c23f4395dfbe3f467c11598049ddb"#用帳戶1測試

#從網頁取得租借時長
def set_User_time(_time):
    global set_time
    set_time=_time

#回傳帳戶餘額
def get_balance():
    return ETH#回傳餘額

#回傳帳戶地址
def get_addrress():
    return address#回傳地址


#進行交易
def transaction():
    global set_time,tx_hash
    #取得已部屬合約的地址(purchase.sol的部署地址)並獲得其ABI
    contract_address = w3.toChecksumAddress('0x2FCE2A13F6F24e4695320640486C05b679Af2d3d')
    with open('build/contracts/purchase.json',encoding="utf-8") as f:
        contract_abi = json.load(f)
    abi = contract_abi["abi"]
    contract = w3.eth.contract(address=contract_address, abi=abi)
    if ETH<1.0:
        print("餘額不足 請向管理室購買ETH")
    else:
        nonce=w3.eth.getTransactionCount(address)
        value=set_time*1000000000000000000
        #帶入私鑰簽署合約
        transaction={
            'to': accounts[0],
            'value': value,#10^18wei = 1ether
            'gas': 2000000,
            'gasPrice': 1,
            'nonce': nonce,
            'chainId': 1
        }
        try:
            signed = w3.eth.account.sign_transaction(transaction, key)#簽署合約
            tx_hash = w3.eth.sendRawTransaction(signed.rawTransaction)#發送到區塊鏈
            return get_transactions(tx_hash)
            
        except:
            return "Error"

#回傳本次交易的塊號
def get_hash():
    with open('templates/purchase.json', 'r') as f:
        data = json.load(f)
    return data['hash']

#把AttributeDict轉成JSON
def toDict(dictToParse):
    # convert any 'AttributeDict' type found to 'dict'
    parsedDict = dict(dictToParse)
    for key, val in parsedDict.items():
        # check for nested dict structures to iterate through
        if  'dict' in str(type(val)).lower():
            parsedDict[key] = toDict(val)
        # convert 'HexBytes' type to 'str'
        elif 'HexBytes' in str(type(val)):
            parsedDict[key] = val.hex()
    return parsedDict

#回傳交易的明細
def get_transactions(tx_hash):
    json_file = json.dumps(toDict(w3.eth.getTransaction(tx_hash)), sort_keys = False, indent = 4, separators = (',', ': '))
    with open('templates/purchase.json', 'w') as f:
        f.write(json_file)
    return json_file
