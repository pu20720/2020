var updateMenu, $html = $(),
    $body = $(),
    $orgMenu = $(),
    $clnMenu = $(),
    $menu = !1,
    api = !1;
$(function () {
    $html = $("html"), $body = $("body"), $orgMenu = $("nav#menu"), $clnMenu = $orgMenu.clone(), updateMenu = function (n, e) {
        $orgMenu.detach();
        var o = !1,
            u = function () {
                $html.removeAttr("class"), $menu && $menu.remove(), $menu = $clnMenu.clone().prependTo("body");
                var u = JSON.parse(JSON.stringify(n)),
                    $ = JSON.parse(JSON.stringify(e)),
                    i = new Mmenu($menu[0], u, $);
                api = i.API, o && "function" == typeof api.open && setTimeout(function () {
                    api.open()
                }, 50)
            };
        $menu && $menu.hasClass("mm-menu_opened") && "function" == typeof api.open ? (o = !0, api.bind("close:finish", u), api.close()) : u()
    }
});
