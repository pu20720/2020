const purchase = artifacts.require('purchase');

module.exports = function(deployer){
    deployer.deploy(purchase);//編譯purchase.sol
};